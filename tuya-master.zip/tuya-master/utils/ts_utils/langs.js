export default {
  deviceOnLineTip: '跳绳已连接',
  deviceOffLineTip: '跳绳未连接',
  connectDevice: '蓝牙正在连接中',
  time: '时长',
  calories: '卡路里',
  modeFreeJump: '自由模式',
  modeCountdownNumber: '计数训练',
  modeCountdownTime: '计时训练',
  lastSkippingRope: '最近一次训练',
  countUnit: '个',
  male: '男',
  female: '女',
  avgSpeed: '平均速度',
  count: '个数',
  
};
